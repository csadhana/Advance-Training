
public class TwoNumbers {
	
	public static void main(String[] args) 
	{
		int i = 1, n = 13, firstNum = 0, secondNum = 1;
	    System.out.println("Fibonacci Series till " + n + " terms:");
	    while (i <= n) 
	    {
	    	System.out.print(firstNum + ", ");
		    int nextNum = firstNum + secondNum;
		    firstNum = secondNum;
		    secondNum = nextNum;
		    i++;
	    }
	  }

}
