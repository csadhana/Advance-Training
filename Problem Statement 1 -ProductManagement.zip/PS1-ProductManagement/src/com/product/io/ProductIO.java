/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.product.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.entity.ProductEntity;

/**
 *
 * @author Nhat
 */
public class ProductIO {

    public boolean save(List<ProductEntity> list) {
        PrintStream ps = null;
        try {
            ps = new PrintStream(new FileOutputStream("dic.dat"));
            for (int i = 0, n = list.size(); i < n; i++) {
                ProductEntity p = list.get(i);
                ps.println(p.getId() + "," + p.getName() + "," + p.getPrice());
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ProductIO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ps.close();
        }
        return false;
    }

    public List<ProductEntity> load() {
        List<ProductEntity> list = new ArrayList<>();
        File file = new File("dic.dat");
        if (file.exists()) {
            try {
                BufferedReader reader = new BufferedReader(new FileReader(file));
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] attributes = line.split(",");
                    int id = Integer.parseInt(attributes[0]);
                    float price = Float.parseFloat(attributes[2]);
                    ProductEntity p = new ProductEntity(id, attributes[1], price);
                    list.add(p);
                }
                reader.close();
            } catch (FileNotFoundException ex) {
                Logger.getLogger(ProductIO.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(ProductIO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return list;
    }
}
