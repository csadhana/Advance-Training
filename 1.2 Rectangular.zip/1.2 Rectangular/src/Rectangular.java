import java.util.Scanner;

public class Rectangular {
	
	int length; 
    int breadth; 
    int area; 
   
    public Rectangular()
    {
    	length = 0;
    	breadth= 0;
    }

    void input() 
    {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = in.nextInt();
        System.out.print("Enter breadth of rectangle: ");
        breadth = in.nextInt();
    }

    void calculate() 
    {
        area = length * breadth;
        
    }

    void display() 
    {
        System.out.println("Area of Rectangle = " + area);
       
    }

    public static void main(String args[]) 
    {
        Rectangular obj1 = new Rectangular();
        obj1.input();
        obj1.calculate();
        obj1.display();
        System.out.println("****************************");
        Rectangular obj2 = new Rectangular();
        obj2.input();
        obj2.calculate();
        obj2.display();
        System.out.println("****************************");
        Rectangular obj3 = new Rectangular();
        obj3.input();
        obj3.calculate();
        obj3.display();
        System.out.println("****************************");
        Rectangular obj4 = new Rectangular();
        obj4.input();
        obj4.calculate();
        obj4.display();
        System.out.println("****************************");
        Rectangular obj5 = new Rectangular();
        obj5.input();
        obj5.calculate();
        obj5.display();
    }

}






